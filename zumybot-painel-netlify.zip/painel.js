'use strict';

async function lerResposta(response) {
  const type = response.headers.get('content-type') || '';
  if (!type.includes('application/json')) {
    throw new Error('O Render ainda não respondeu ao painel. Confira o status do serviço e tente novamente.');
  }
  return response.json();
}

  const form = document.getElementById('pair');
  const token = document.getElementById('token');
  const number = document.getElementById('number');
  const result = document.getElementById('result');
  const code = document.getElementById('code');
  const qrImage = document.getElementById('qr');
  const buttons = Array.from(form.querySelectorAll('button'));
  async function pair(action) {
    if (buttons[0].disabled) return;
    if (!token.value.trim()) {
      result.textContent = 'Informe o ADMIN_TOKEN do Render.';
      token.focus();
      return;
    }
    buttons.forEach(button => button.disabled = true);
    qrImage.hidden = true;
    qrImage.removeAttribute('src');
    code.textContent = '';
    result.textContent = 'Aguarde…';
    const authorization = 'Bearer ' + token.value.trim();
    try {
      const options = { headers: { Authorization: authorization }, cache: 'no-store' };
      if (action !== 'qr-image') {
        options.method = 'POST';
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify({ number: number.value });
      }
      const response = await fetch('/admin/' + action, options);
      const data = await lerResposta(response);
      if (!response.ok) throw new Error(data.error || 'Não foi possível concluir a solicitação.');
      if (action === 'qr-image') {
        qrImage.src = data.image;
        qrImage.hidden = false;
        result.textContent = 'Escaneie o QR Code em Aparelhos conectados. Se expirar, toque em Mostrar QR Code de novo.';
      } else if (action === 'pair-reset') {
        result.textContent = 'Nova sessão em preparação. Aguarde alguns segundos e tente Mostrar QR Code ou Gerar código.';
      } else {
        code.textContent = data.code;
        result.textContent = 'Digite este código no WhatsApp do bot.';
      }
    } catch (error) {
      result.textContent = error.message === 'Failed to fetch'
        ? 'Falha ao acessar o serviço. Tente novamente.'
        : error.message;
    } finally {
      buttons.forEach(button => button.disabled = false);
    }
  }
  form.addEventListener('submit', event => { event.preventDefault(); void pair('pair'); });
  document.getElementById('show-qr').addEventListener('click', () => void pair('qr-image'));
  document.getElementById('reset').addEventListener('click', () => void pair('pair-reset'));
  const el = id => document.getElementById(id);
  async function admin(path, body) {
    if (!token.value.trim()) throw new Error('Informe o ADMIN_TOKEN do Render.');
    const headers = { Authorization: 'Bearer ' + token.value.trim() };
    const options = { headers, cache: 'no-store' };
    if (body !== undefined) {
      options.method = 'POST';
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    const response = await fetch('/admin/' + path, options);
    const data = await lerResposta(response);
    if (!response.ok) throw new Error(data.error || 'Não foi possível concluir.');
    return data;
  }
  async function executar(statusId, action) {
    const aviso = el(statusId);
    aviso.textContent = 'Aguarde…';
    try { aviso.textContent = await action(); }
    catch (error) { aviso.textContent = error.message; }
  }
  el('settings-load').addEventListener('click', () => void executar('owner-result', async () => {
    const dono = await admin('owner');
    el('owner-name').value = dono.name;
    el('owner-number').value = dono.number;
    el('owner-lid').value = dono.lid || '';
    return 'Cadastro carregado.';
  }));
  el('owner').addEventListener('submit', event => {
    event.preventDefault();
    void executar('owner-result', async () => {
      await admin('owner', { name: el('owner-name').value, number: el('owner-number').value, lid: el('owner-lid').value });
      return 'Dono salvo. Teste !dono e !reiniciar no grupo.';
    });
  });
  const fields = {
    nickname: 'group-name', welcomeText: 'group-welcome', goodbyeText: 'group-goodbye',
    welcomeText2: 'group-welcome2', goodbyeText2: 'group-goodbye2', mode: 'group-greet'
  };
  let groupSelection = 0;
  el('settings-groups').addEventListener('click', () => void executar('group-result', async () => {
    const { groups } = await admin('groups');
    groupSelection++;
    el('group-fields').disabled = true;
    const first = document.createElement('option');
    first.value = '';
    first.textContent = 'Selecione um grupo';
    el('group-id').replaceChildren(first);
    for (const group of groups) {
      const option = document.createElement('option');
      option.value = group.id;
      option.textContent = group.name;
      el('group-id').append(option);
    }
    return groups.length ? 'Grupos sincronizados. Selecione um grupo.' : 'O bot não participa de grupos.';
  }));
  el('group-id').addEventListener('change', () => {
    const selection = ++groupSelection;
    const jid = el('group-id').value;
    el('group-fields').disabled = true;
    if (!jid) return;
    void executar('group-result', async () => {
      const values = await admin('group?jid=' + encodeURIComponent(jid));
      if (selection !== groupSelection) return '';
      for (const [key, id] of Object.entries(fields)) el(id).value = values[key] || '';
      el('group-fields').disabled = false;
      return 'Configuração carregada.';
    });
  });
  el('group').addEventListener('submit', event => {
    event.preventDefault();
    const jid = el('group-id').value;
    const values = Object.fromEntries(Object.entries(fields).map(([key, id]) => [key, el(id).value]));
    void executar('group-result', async () => {
      await admin('group', { jid, ...values });
      return 'Configuração do grupo salva. O bot já pode usá-la.';
    });
  });


async function atualizarStatus() {
  try {
    const resposta = await fetch('/health', { cache: 'no-store', signal: AbortSignal.timeout(12000) });
    if (!resposta.ok) throw new Error('Serviço indisponível');
    const {status, revisao, funcoes} = await lerResposta(resposta);
    if (typeof status !== 'string') throw new Error('Status inválido');
    el('health-status').textContent = 'WhatsApp: ' + status.replaceAll('_', ' ') +
      (funcoes ? ' · Funções ' + funcoes : '') + (revisao ? ' · ' + revisao : '');
  } catch {
    el('health-status').textContent = 'Status indisponível. Confira o serviço no Render.';
  } finally {
    setTimeout(atualizarStatus, 15000);
  }
}
void atualizarStatus();
